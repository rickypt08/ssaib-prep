import { useState, useEffect, useCallback } from "react";

// ─── DATA ───────────────────────────────────────────────────────────────────

const SCHEMES = {
  alarm: {
    id: "alarm",
    label: "Intruder Alarms",
    standard: "BS EN 50131",
    color: "#E8441A",
    icon: "🔔",
  },
  cctv: {
    id: "cctv",
    label: "CCTV / Surveillance",
    standard: "BS EN 62676",
    color: "#1A7EE8",
    icon: "📷",
  },
};

const CHECKLIST_DATA = {
  alarm: {
    label: "Intruder Alarms – BS EN 50131",
    sections: [
      {
        id: "alarm_company",
        title: "Company & Legal Requirements",
        items: [
          { id: "a_co_1", text: "Company registration documents (Companies House / sole trader proof)" },
          { id: "a_co_2", text: "Public liability insurance certificate (min £2m)" },
          { id: "a_co_3", text: "Employers liability insurance certificate" },
          { id: "a_co_4", text: "Professional indemnity insurance certificate" },
          { id: "a_co_5", text: "VAT registration (if applicable)" },
          { id: "a_co_6", text: "Health & Safety policy document (signed & dated)" },
          { id: "a_co_7", text: "COSHH risk assessments in place" },
          { id: "a_co_8", text: "Method statements / safe working procedures" },
        ],
      },
      {
        id: "alarm_staff",
        title: "Personnel & Vetting",
        items: [
          { id: "a_st_1", text: "BS 7858 screening completed for all staff (enhanced DBS / background check)" },
          { id: "a_st_2", text: "Vetting records held on file for all engineers & admin" },
          { id: "a_st_3", text: "Competency records / training certificates for each engineer" },
          { id: "a_st_4", text: "First aid certificate held by at least one person" },
          { id: "a_st_5", text: "Engineer ID cards issued" },
          { id: "a_st_6", text: "Staff contracts referencing confidentiality obligations" },
        ],
      },
      {
        id: "alarm_technical",
        title: "Technical Competence – BS EN 50131",
        items: [
          { id: "a_te_1", text: "Engineers trained / certificated to BS EN 50131 (e.g. BTEC, City & Guilds, EAL, FIA)" },
          { id: "a_te_2", text: "Knowledge of Grade 1–4 system requirements demonstrated" },
          { id: "a_te_3", text: "Control panel manufacturer training records held" },
          { id: "a_te_4", text: "Awareness of PD 6662 (scheme of requirements for intruder alarms)" },
          { id: "a_te_5", text: "Knowledge of ARCs (Alarm Receiving Centres) and signalling standards" },
          { id: "a_te_6", text: "Compliance with BS 8243 (conditions for intruder alarms with police response)" },
          { id: "a_te_7", text: "Detector placement, zone mapping, and tamper protection understood" },
        ],
      },
      {
        id: "alarm_docs",
        title: "Documentation & Quality Management",
        items: [
          { id: "a_do_1", text: "Quality Management System (QMS) documented and in use" },
          { id: "a_do_2", text: "Installation standard operating procedures written" },
          { id: "a_do_3", text: "Commissioning / inspection record forms (SSAIB approved)" },
          { id: "a_do_4", text: "Customer contracts / terms & conditions template" },
          { id: "a_do_5", text: "Maintenance agreement template (annual / bi-annual)" },
          { id: "a_do_6", text: "Non-conformance / corrective action procedure" },
          { id: "a_do_7", text: "Complaints procedure documented" },
          { id: "a_do_8", text: "Record of at least 3 completed installation files (new build required)" },
        ],
      },
      {
        id: "alarm_monitoring",
        title: "Monitoring & Response",
        items: [
          { id: "a_mo_1", text: "Written agreement with an NSI / SSAIB approved ARC" },
          { id: "a_mo_2", text: "Unique Reference Numbers (URNs) procedure understood" },
          { id: "a_mo_3", text: "False alarm management policy in place" },
          { id: "a_mo_4", text: "Call handling / key holder contact procedures documented" },
        ],
      },
      {
        id: "alarm_ssaib",
        title: "SSAIB Application Requirements",
        items: [
          { id: "a_ss_1", text: "SSAIB application form completed and submitted" },
          { id: "a_ss_2", text: "Application fee paid" },
          { id: "a_ss_3", text: "Pre-assessment questionnaire returned to SSAIB" },
          { id: "a_ss_4", text: "Sample installation files sent to SSAIB for review" },
          { id: "a_ss_5", text: "Audit date agreed with SSAIB assessor" },
          { id: "a_ss_6", text: "Premises ready for office audit (QMS, records, staff evidence)" },
          { id: "a_ss_7", text: "At least one live installation available for site audit" },
        ],
      },
    ],
  },
  cctv: {
    label: "CCTV / Surveillance – BS EN 62676",
    sections: [
      {
        id: "cctv_company",
        title: "Company & Legal Requirements",
        items: [
          { id: "c_co_1", text: "Company registration documents (Companies House / sole trader proof)" },
          { id: "c_co_2", text: "Public liability insurance certificate (min £2m)" },
          { id: "c_co_3", text: "Employers liability insurance certificate" },
          { id: "c_co_4", text: "ICO (Information Commissioner's Office) registration – Data Controller" },
          { id: "c_co_5", text: "Data Protection / GDPR policy documented" },
          { id: "c_co_6", text: "Health & Safety policy document (signed & dated)" },
          { id: "c_co_7", text: "COSHH risk assessments in place" },
        ],
      },
      {
        id: "cctv_staff",
        title: "Personnel & Vetting",
        items: [
          { id: "c_st_1", text: "BS 7858 screening completed for all staff" },
          { id: "c_st_2", text: "Vetting records held on file for all engineers" },
          { id: "c_st_3", text: "CCTV-specific training certificates (e.g. BTEC L3, EAL, NSQ)" },
          { id: "c_st_4", text: "Working at height training (PASMA / IPAF) where applicable" },
          { id: "c_st_5", text: "Engineer ID cards issued" },
        ],
      },
      {
        id: "cctv_technical",
        title: "Technical Competence – BS EN 62676",
        items: [
          { id: "c_te_1", text: "Engineers trained on BS EN 62676 Part 1–4 requirements" },
          { id: "c_te_2", text: "Understanding of camera classes (environment, colour, resolution)" },
          { id: "c_te_3", text: "Site survey and system design principles documented" },
          { id: "c_te_4", text: "IP networking / PoE knowledge (where IP systems installed)" },
          { id: "c_te_5", text: "Recording requirements understood (frame rate, retention, evidential quality)" },
          { id: "c_te_6", text: "Knowledge of DPIA (Data Protection Impact Assessment) for CCTV sites" },
          { id: "c_te_7", text: "Signage requirements under UK GDPR understood" },
          { id: "c_te_8", text: "Access control to DVR / NVR documented" },
        ],
      },
      {
        id: "cctv_docs",
        title: "Documentation & Quality Management",
        items: [
          { id: "c_do_1", text: "Quality Management System (QMS) documented and in use" },
          { id: "c_do_2", text: "CCTV installation standard operating procedures written" },
          { id: "c_do_3", text: "Commissioning / inspection record forms (SSAIB approved)" },
          { id: "c_do_4", text: "Customer contracts / terms & conditions (including data clauses)" },
          { id: "c_do_5", text: "Maintenance agreement template" },
          { id: "c_do_6", text: "Non-conformance / corrective action procedure" },
          { id: "c_do_7", text: "Complaints procedure documented" },
          { id: "c_do_8", text: "Record of at least 3 completed CCTV installation files" },
          { id: "c_do_9", text: "CCTV system design drawings / camera layout plans on file" },
        ],
      },
      {
        id: "cctv_gdpr",
        title: "GDPR & Privacy Compliance",
        items: [
          { id: "c_gd_1", text: "Privacy notice / fair processing notice for end customers" },
          { id: "c_gd_2", text: "DPIA template provided to customers where required" },
          { id: "c_gd_3", text: "Data retention policy (footage deletion schedule)" },
          { id: "c_gd_4", text: "Subject Access Request (SAR) procedure documented" },
          { id: "c_gd_5", text: "Secure disposal of recordings / hardware procedure" },
          { id: "c_gd_6", text: "Staff data protection awareness training records" },
        ],
      },
      {
        id: "cctv_ssaib",
        title: "SSAIB Application Requirements",
        items: [
          { id: "c_ss_1", text: "SSAIB application form completed and submitted" },
          { id: "c_ss_2", text: "Application fee paid" },
          { id: "c_ss_3", text: "Pre-assessment questionnaire returned to SSAIB" },
          { id: "c_ss_4", text: "Sample CCTV installation files sent to SSAIB for review" },
          { id: "c_ss_5", text: "Audit date agreed with SSAIB assessor" },
          { id: "c_ss_6", text: "Premises ready for office audit (QMS, records, staff evidence)" },
          { id: "c_ss_7", text: "At least one live CCTV installation available for site audit" },
        ],
      },
    ],
  },
};

const DOCUMENT_TEMPLATES = [
  {
    id: "qms",
    title: "Quality Management System (QMS) Overview",
    scheme: "both",
    category: "Quality",
    content: `QUALITY MANAGEMENT SYSTEM
Company: ___________________________
Date: ___________________________
Review Date: ___________________________

1. SCOPE
This QMS applies to the design, supply, installation, commissioning and maintenance of:
  ☐ Intruder Alarm Systems (BS EN 50131 / PD 6662)
  ☐ CCTV / Surveillance Systems (BS EN 62676)

2. QUALITY POLICY
[Company name] is committed to:
• Delivering installations that meet or exceed SSAIB and British Standards requirements
• Continuous improvement of our processes and service quality
• Customer satisfaction at every stage
• Compliance with all relevant legislation

Signed (Director): ___________________________  Date: ___________

3. KEY PROCEDURES (attach each as appendix)
  ☐ Installation & Commissioning Procedure
  ☐ Inspection & Testing Procedure
  ☐ Maintenance Procedure
  ☐ Non-Conformance & Corrective Action
  ☐ Customer Complaints Procedure
  ☐ Document Control Procedure
  ☐ Risk Assessment Procedure

4. DOCUMENT CONTROL
All documents to carry: Document No. | Version | Date | Author | Approved by

5. INTERNAL AUDIT SCHEDULE
Frequency: Annually (minimum)
Next audit date: ___________________________
Conducted by: ___________________________`,
  },
  {
    id: "installation_record_alarm",
    title: "Intruder Alarm Installation Record",
    scheme: "alarm",
    category: "Installation",
    content: `INTRUDER ALARM INSTALLATION RECORD
Ref No: ____________  Date: ____________

CUSTOMER DETAILS
Name: ___________________________
Address: ___________________________
Contact No: ___________________________
Email: ___________________________

SYSTEM DETAILS
Panel Make / Model: ___________________________
Grade: ☐ 1  ☐ 2  ☐ 3  ☐ 4
Number of zones: _______
Signalling: ☐ Digital  ☐ GPRS  ☐ IP  ☐ None
ARC Name: ___________________________  URN: ___________________________

DETECTION DEVICES
Zone | Type | Location | Grade
1.
2.
3.
(continue as required)

SOUNDER / BELL BOX
External: Make _____________ Location _____________
Internal: Make _____________ Location _____________

COMMISSIONING CHECKS
☐ All zones walk-tested and confirmed operational
☐ Tamper circuits tested (panel, detectors, bell box)
☐ Battery backup tested (min 12hr standby)
☐ Signalling path to ARC tested and confirmed
☐ User codes set and customer briefed
☐ Key holder details registered with ARC
☐ False alarm documentation handed to customer
☐ System documentation / user manual handed over

ENGINEER SIGN-OFF
Name: ___________________________
Signature: ___________________________
Date: ___________________________

CUSTOMER ACCEPTANCE
I confirm the system has been demonstrated to my satisfaction.
Name: ___________________________
Signature: ___________________________
Date: ___________________________`,
  },
  {
    id: "installation_record_cctv",
    title: "CCTV Installation Record",
    scheme: "cctv",
    category: "Installation",
    content: `CCTV INSTALLATION RECORD
Ref No: ____________  Date: ____________

CUSTOMER DETAILS
Name: ___________________________
Address: ___________________________
Contact No: ___________________________
Email: ___________________________

SYSTEM DETAILS
DVR / NVR Make / Model: ___________________________
Storage Capacity: _______TB  Retention Period: _______ days
Network Type: ☐ Analogue (HD-CVI/TVI/AHD)  ☐ IP/PoE  ☐ Hybrid
Remote Access: ☐ Yes  ☐ No   App/Platform: ___________________________

CAMERAS
No. | Make/Model | Type | Resolution | Location | IR Range
1.
2.
3.
(continue as required)

COMMISSIONING CHECKS
☐ All cameras displaying clear images (day & night tested)
☐ Recording confirmed on all channels
☐ Motion detection configured
☐ Remote access tested and confirmed
☐ DVR/NVR password set (not default)
☐ Recording schedule configured
☐ Retention period confirmed meets customer requirement
☐ CCTV warning signage installed at access points
☐ Customer briefed on GDPR obligations (ICO registration advised)
☐ System documentation / user manual handed over
☐ Data retention / deletion procedure explained

ENGINEER SIGN-OFF
Name: ___________________________
Signature: ___________________________
Date: ___________________________

CUSTOMER ACCEPTANCE
I confirm the system has been demonstrated to my satisfaction.
Name: ___________________________
Signature: ___________________________
Date: ___________________________`,
  },
  {
    id: "maintenance_template",
    title: "Maintenance Agreement Template",
    scheme: "both",
    category: "Contracts",
    content: `MAINTENANCE AGREEMENT
Agreement No: ____________

PARTIES
Company: ___________________________
Customer: ___________________________
Site Address: ___________________________

SYSTEM COVERED
☐ Intruder Alarm  ☐ CCTV  ☐ Both
Installed Date: ___________________________

SERVICE LEVEL
☐ Gold – 2 visits per year + 24hr emergency callout
☐ Silver – 1 visit per year + next working day callout
☐ Bronze – 1 visit per year, no emergency cover

ANNUAL CHARGE
£ _______________ + VAT   (reviewed annually)

SCOPE OF MAINTENANCE VISIT
• Full system function test
• Battery condition check and test
• Detector sensitivity / lens clean
• All signalling paths tested to ARC (where applicable)
• Software / firmware update (if available)
• Written report provided after each visit

CALLOUT RESPONSE TIMES
Emergency (Gold): 4 hours
Standard: Next working day

CUSTOMER OBLIGATIONS
• Provide access at agreed times
• Notify company of any changes to the premises
• Maintain URN registration (alarms)
• Maintain ICO registration (CCTV)

Agreement Start Date: ___________________________
Agreement End Date: ___________________________
Notice Period: 30 days written notice

Signed (Company): ___________________________  Date: ___________
Signed (Customer): ___________________________  Date: ___________`,
  },
  {
    id: "risk_assessment",
    title: "Generic Installation Risk Assessment",
    scheme: "both",
    category: "Health & Safety",
    content: `RISK ASSESSMENT
Company: ___________________________
Assessment Ref: ____________  Date: ____________
Activity: Installation of Security Systems

Assessor: ___________________________  Reviewed By: ___________________________

HAZARD IDENTIFICATION (Risk Rating: L=Low M=Medium H=High)

1. Working at Height (ladders, steps)
   Risk: H | Controls: Use appropriate ladder / steps, 3-point contact, no overreaching
   Residual Risk: L  ☐ Reviewed

2. Manual Handling (heavy DVR / NVR equipment, cable drums)
   Risk: M | Controls: Two-person lift for items >25kg, use trolley where possible
   Residual Risk: L  ☐ Reviewed

3. Electrical Work (drilling near cables, 240v connections)
   Risk: H | Controls: Use cable avoidance tool, isolate supplies before work, 18th Ed competence
   Residual Risk: L  ☐ Reviewed

4. Dust / Debris (drilling masonry, ceilings)
   Risk: M | Controls: Dust mask (FFP2), safety glasses, dust sheets
   Residual Risk: L  ☐ Reviewed

5. Slips, Trips (trailing cables, tools on floor)
   Risk: M | Controls: Tidy as you go, cordon off work area, use cable tidies
   Residual Risk: L  ☐ Reviewed

6. Lone Working
   Risk: M | Controls: Sign in / out procedure, check-in call at lunchtime and end of day
   Residual Risk: L  ☐ Reviewed

7. Working in Occupied Premises
   Risk: M | Controls: Inform site contact, keep work area tidy, respect vulnerable persons
   Residual Risk: L  ☐ Reviewed

PPE REQUIRED
☐ Safety boots  ☐ Safety glasses  ☐ Dust mask (FFP2)  ☐ Hi-vis (external work)  ☐ Gloves

EMERGENCY PROCEDURES
Nearest hospital: ___________________________
First Aider: ___________________________
Site emergency contact: ___________________________`,
  },
  {
    id: "complaints_procedure",
    title: "Customer Complaints Procedure",
    scheme: "both",
    category: "Quality",
    content: `CUSTOMER COMPLAINTS PROCEDURE
Document No: QMS-003  Version: 1.0  Date: ____________

PURPOSE
To ensure all customer complaints are handled promptly, fairly and professionally, and used to drive improvement.

SCOPE
All complaints received by [Company Name] regarding installation, maintenance or service.

PROCEDURE

Step 1 – Receipt of Complaint
• All complaints (telephone, email, written) logged in Complaints Register within 24 hours
• Complaint acknowledged to customer within 2 working days
• Complaint assigned to a named handler (Director / Senior Engineer)

Step 2 – Investigation
• Full investigation completed within 10 working days
• Customer kept informed of progress
• Root cause identified

Step 3 – Resolution
• Resolution offered to customer (remedy, revisit, refund as appropriate)
• Customer acceptance of resolution recorded
• Corrective action raised if systemic issue identified

Step 4 – Close-Out
• Complaint closed in register with outcome noted
• If complaint relates to SSAIB scheme work, SSAIB notified if required
• Lessons learned fed back to team

ESCALATION
If unresolved: Director review within 5 further working days.
SSAIB operate a complaints escalation process for scheme-related matters.
SSAIB: www.ssaib.org | 0191 296 3242

COMPLAINTS REGISTER FIELDS
Date | Customer | Nature | Handler | Resolution | Close Date | Outcome`,
  },
  {
    id: "non_conformance",
    title: "Non-Conformance & Corrective Action Form",
    scheme: "both",
    category: "Quality",
    content: `NON-CONFORMANCE & CORRECTIVE ACTION RECORD
Form No: ____________  Date Raised: ____________
Raised By: ___________________________

DESCRIPTION OF NON-CONFORMANCE
(What happened / what was found to be wrong?)

___________________________

JOB REF / SITE AFFECTED
___________________________

IMMEDIATE ACTION TAKEN
(What was done to fix the immediate problem?)

___________________________

ROOT CAUSE ANALYSIS
☐ Inadequate training
☐ Inadequate procedure / no procedure existed
☐ Human error
☐ Equipment / material failure
☐ Communication failure
☐ Other: ___________________________

ROOT CAUSE DETAIL:

___________________________

CORRECTIVE ACTION (to prevent recurrence)
Action: ___________________________
Responsible Person: ___________________________
Target Date: ___________________________

VERIFICATION
Corrective action confirmed effective: ___________________________
Verified By: ___________________________  Date: ___________________________

CLOSE-OUT
Form closed: ___________________________  Signed: ___________________________`,
  },
  {
    id: "vetting_record",
    title: "Staff Vetting Record (BS 7858)",
    scheme: "both",
    category: "Personnel",
    content: `STAFF VETTING RECORD – BS 7858
CONFIDENTIAL – HR USE ONLY

Employee Name: ___________________________
Date of Birth: ___________________________
Start Date: ___________________________
Role: ___________________________

IDENTITY VERIFICATION
☐ Passport / Photo ID verified and copy held
☐ Proof of address (utility bill / bank statement – within 3 months)
☐ National Insurance number verified
☐ Right to work in UK confirmed

EMPLOYMENT HISTORY (last 5 years minimum)
From | To | Employer | Role | Verified By | Date Verified
_____|____|__________|______|_____________|_____________

CRIMINAL RECORD CHECK
☐ DBS Standard  ☐ DBS Enhanced  ☐ Basic Disclosure
DBS Certificate No: ___________________________
Date of Check: ___________________________
Result: ☐ Clear  ☐ Declared (details held separately)

REFERENCES
Referee 1: Name _____________ Company _____________ Date _____________ ☐ Satisfactory
Referee 2: Name _____________ Company _____________ Date _____________ ☐ Satisfactory

DECLARATION (Employee)
I confirm the information provided is accurate and complete.
Signature: ___________________________  Date: ___________________________

AUTHORISED BY (Director / HR)
Name: ___________________________
Signature: ___________________________  Date: ___________________________
Next Review Date: ___________________________`,
  },
];

// ─── STORAGE HELPERS ────────────────────────────────────────────────────────

const STORAGE_KEY = "ssaib_app_v1";

function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (_) {}
  return { checked: {}, uploads: {}, notes: {} };
}

function saveState(state) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (_) {}
}

// ─── PROGRESS BAR ───────────────────────────────────────────────────────────

function ProgressRing({ pct, color, size = 56 }) {
  const r = (size - 8) / 2;
  const circ = 2 * Math.PI * r;
  const dash = (pct / 100) * circ;
  return (
    <svg width={size} height={size}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#2a2a2a" strokeWidth={6} />
      <circle
        cx={size / 2} cy={size / 2} r={r} fill="none"
        stroke={color} strokeWidth={6}
        strokeDasharray={`${dash} ${circ}`}
        strokeLinecap="round"
        transform={`rotate(-90 ${size / 2} ${size / 2})`}
        style={{ transition: "stroke-dasharray 0.5s ease" }}
      />
      <text x="50%" y="50%" textAnchor="middle" dy="0.35em" fill="#fff" fontSize={size * 0.22} fontFamily="'DM Mono', monospace" fontWeight="700">
        {pct}%
      </text>
    </svg>
  );
}

// ─── MAIN APP ────────────────────────────────────────────────────────────────

export default function SSAIBApp() {
  const [state, setState] = useState(loadState);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [activeScheme, setActiveScheme] = useState("alarm");
  const [expandedSections, setExpandedSections] = useState({});
  const [activeDoc, setActiveDoc] = useState(null);
  const [docFilter, setDocFilter] = useState("all");
  const [toast, setToast] = useState(null);

  useEffect(() => { saveState(state); }, [state]);

  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 2800);
  };

  // ── Checklist helpers ──────────────────────────────────────────────────────

  const toggleItem = useCallback((id) => {
    setState(prev => {
      const checked = { ...prev.checked, [id]: !prev.checked[id] };
      return { ...prev, checked };
    });
  }, []);

  const schemeProgress = (schemeId) => {
    const data = CHECKLIST_DATA[schemeId];
    const all = data.sections.flatMap(s => s.items);
    const done = all.filter(i => state.checked[i.id]).length;
    return { done, total: all.length, pct: all.length ? Math.round((done / all.length) * 100) : 0 };
  };

  const sectionProgress = (section) => {
    const done = section.items.filter(i => state.checked[i.id]).length;
    return { done, total: section.items.length };
  };

  // ── Upload helpers ─────────────────────────────────────────────────────────

  const handleFileUpload = useCallback((docId, file) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      setState(prev => ({
        ...prev,
        uploads: {
          ...prev.uploads,
          [docId]: [...(prev.uploads[docId] || []), {
            name: file.name,
            size: file.size,
            type: file.type,
            data: e.target.result,
            uploadedAt: new Date().toISOString(),
          }],
        },
      }));
      showToast(`"${file.name}" uploaded`);
    };
    reader.readAsDataURL(file);
  }, []);

  const removeUpload = useCallback((docId, idx) => {
    setState(prev => {
      const arr = [...(prev.uploads[docId] || [])];
      arr.splice(idx, 1);
      return { ...prev, uploads: { ...prev.uploads, [docId]: arr } };
    });
    showToast("File removed", "info");
  }, []);

  // ── Section toggle ─────────────────────────────────────────────────────────

  const toggleSection = (id) => setExpandedSections(prev => ({ ...prev, [id]: !prev[id] }));

  // ── Counts ────────────────────────────────────────────────────────────────

  const alarmProg = schemeProgress("alarm");
  const cctvProg = schemeProgress("cctv");
  const totalUploads = Object.values(state.uploads).flat().length;

  // ─── RENDER ───────────────────────────────────────────────────────────────

  const docCategories = ["all", ...new Set(DOCUMENT_TEMPLATES.map(d => d.category))];
  const filteredDocs = DOCUMENT_TEMPLATES.filter(d =>
    docFilter === "all" || d.category === docFilter
  );

  return (
    <div style={{
      minHeight: "100vh", background: "#0d0d0d", color: "#e8e8e8",
      fontFamily: "'DM Sans', sans-serif",
    }}>
      {/* Google Fonts */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&family=DM+Mono:wght@400;500;700&family=Syne:wght@700;800&display=swap');

        * { box-sizing: border-box; margin: 0; padding: 0; }

        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #1a1a1a; }
        ::-webkit-scrollbar-thumb { background: #333; border-radius: 3px; }

        .nav-btn {
          background: none; border: none; cursor: pointer; color: #888;
          font-family: 'DM Mono', monospace; font-size: 11px; font-weight: 500;
          letter-spacing: 0.08em; text-transform: uppercase;
          padding: 10px 16px; border-radius: 6px; transition: all 0.2s;
          display: flex; flex-direction: column; align-items: center; gap: 5px;
        }
        .nav-btn:hover { color: #fff; background: #1e1e1e; }
        .nav-btn.active { color: #fff; background: #1e1e1e; }
        .nav-btn.active .nav-dot { opacity: 1; }
        .nav-dot {
          width: 4px; height: 4px; border-radius: 50%;
          background: #E8441A; opacity: 0;
          transition: opacity 0.2s;
        }

        .card {
          background: #161616; border: 1px solid #252525;
          border-radius: 12px; padding: 20px;
          transition: border-color 0.2s;
        }
        .card:hover { border-color: #333; }

        .check-item {
          display: flex; align-items: flex-start; gap: 12px; padding: 10px 0;
          border-bottom: 1px solid #1e1e1e; cursor: pointer;
          transition: all 0.15s;
        }
        .check-item:last-child { border-bottom: none; }
        .check-item:hover { padding-left: 4px; }

        .checkbox {
          width: 20px; height: 20px; border-radius: 5px; flex-shrink: 0;
          border: 2px solid #333; background: none; cursor: pointer;
          display: flex; align-items: center; justify-content: center;
          transition: all 0.2s; margin-top: 1px;
        }
        .checkbox.checked { background: #22c55e; border-color: #22c55e; }
        .checkbox.alarm-checked { background: #E8441A; border-color: #E8441A; }
        .checkbox.cctv-checked { background: #1A7EE8; border-color: #1A7EE8; }

        .scheme-tab {
          padding: 8px 20px; border-radius: 20px; cursor: pointer;
          font-family: 'DM Mono', monospace; font-size: 12px; font-weight: 500;
          text-transform: uppercase; letter-spacing: 0.06em;
          border: 1px solid #333; background: none; color: #888;
          transition: all 0.2s;
        }
        .scheme-tab:hover { color: #fff; }
        .scheme-tab.active-alarm { background: #E8441A22; border-color: #E8441A88; color: #E8441A; }
        .scheme-tab.active-cctv { background: #1A7EE822; border-color: #1A7EE888; color: #1A7EE8; }

        .upload-zone {
          border: 2px dashed #333; border-radius: 10px; padding: 24px;
          text-align: center; cursor: pointer; transition: all 0.2s;
          background: #111;
        }
        .upload-zone:hover { border-color: #555; background: #161616; }

        .tag {
          display: inline-block; padding: 2px 8px; border-radius: 4px;
          font-family: 'DM Mono', monospace; font-size: 10px; font-weight: 500;
          text-transform: uppercase; letter-spacing: 0.06em;
        }

        .section-header {
          display: flex; align-items: center; justify-content: space-between;
          padding: 14px 16px; cursor: pointer; border-radius: 8px;
          transition: background 0.15s; user-select: none;
        }
        .section-header:hover { background: #1e1e1e; }

        .progress-bar {
          height: 4px; background: #222; border-radius: 2px; overflow: hidden;
        }
        .progress-fill {
          height: 100%; border-radius: 2px; transition: width 0.5s ease;
        }

        .doc-card {
          background: #161616; border: 1px solid #252525; border-radius: 10px;
          padding: 16px; cursor: pointer; transition: all 0.2s;
        }
        .doc-card:hover { border-color: #444; transform: translateY(-1px); }

        .modal-overlay {
          position: fixed; inset: 0; background: rgba(0,0,0,0.8);
          display: flex; align-items: center; justify-content: center;
          z-index: 1000; padding: 16px; backdrop-filter: blur(4px);
        }
        .modal {
          background: #141414; border: 1px solid #2a2a2a; border-radius: 14px;
          width: 100%; max-width: 680px; max-height: 85vh; overflow: hidden;
          display: flex; flex-direction: column;
        }

        .btn {
          padding: 10px 20px; border-radius: 8px; border: none; cursor: pointer;
          font-family: 'DM Sans', sans-serif; font-weight: 600; font-size: 14px;
          transition: all 0.2s;
        }
        .btn-primary { background: #E8441A; color: #fff; }
        .btn-primary:hover { background: #d03a14; }
        .btn-outline { background: none; border: 1px solid #333; color: #aaa; }
        .btn-outline:hover { border-color: #555; color: #fff; }

        .toast {
          position: fixed; bottom: 80px; left: 50%; transform: translateX(-50%);
          background: #1e1e1e; border: 1px solid #333; color: #fff;
          padding: 10px 20px; border-radius: 8px; font-size: 14px;
          z-index: 2000; animation: toastIn 0.3s ease;
        }
        @keyframes toastIn {
          from { opacity: 0; transform: translateX(-50%) translateY(10px); }
          to { opacity: 1; transform: translateX(-50%) translateY(0); }
        }

        .filter-btn {
          padding: 6px 14px; border-radius: 16px; border: 1px solid #2a2a2a;
          background: none; color: #777; cursor: pointer; font-size: 12px;
          font-family: 'DM Mono', monospace; text-transform: uppercase;
          letter-spacing: 0.05em; transition: all 0.2s;
        }
        .filter-btn:hover, .filter-btn.active { background: #222; border-color: #444; color: #fff; }

        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .fade-in { animation: fadeIn 0.3s ease; }
      `}</style>

      {/* Header */}
      <div style={{ background: "#101010", borderBottom: "1px solid #1e1e1e", padding: "16px 20px", position: "sticky", top: 0, zIndex: 100 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 800, fontSize: 20, letterSpacing: "-0.02em", color: "#fff" }}>
              SSAIB<span style={{ color: "#E8441A" }}>·</span>PREP
            </div>
            <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 10, color: "#555", letterSpacing: "0.1em", textTransform: "uppercase", marginTop: 2 }}>
              Accreditation Manager
            </div>
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            <div style={{ background: "#E8441A18", border: "1px solid #E8441A44", borderRadius: 6, padding: "4px 10px", textAlign: "center" }}>
              <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 18, fontWeight: 700, color: "#E8441A" }}>{alarmProg.pct}%</div>
              <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 9, color: "#E8441A88", textTransform: "uppercase" }}>Alarm</div>
            </div>
            <div style={{ background: "#1A7EE818", border: "1px solid #1A7EE844", borderRadius: 6, padding: "4px 10px", textAlign: "center" }}>
              <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 18, fontWeight: 700, color: "#1A7EE8" }}>{cctvProg.pct}%</div>
              <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 9, color: "#1A7EE888", textTransform: "uppercase" }}>CCTV</div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div style={{ padding: "16px 16px 100px", maxWidth: 800, margin: "0 auto" }}>

        {/* ── DASHBOARD ──────────────────────────────────────────────────── */}
        {activeTab === "dashboard" && (
          <div className="fade-in">
            <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 22, marginBottom: 4 }}>Dashboard</div>
            <div style={{ color: "#555", fontSize: 13, marginBottom: 20 }}>Your SSAIB accreditation overview</div>

            {/* Scheme cards */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 20 }}>
              {[
                { scheme: "alarm", prog: alarmProg, color: "#E8441A" },
                { scheme: "cctv", prog: cctvProg, color: "#1A7EE8" },
              ].map(({ scheme, prog, color }) => (
                <div key={scheme} className="card" style={{ borderColor: `${color}33` }}>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
                    <div>
                      <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 10, color: "#555", textTransform: "uppercase", letterSpacing: "0.08em" }}>
                        {SCHEMES[scheme].standard}
                      </div>
                      <div style={{ fontWeight: 600, fontSize: 14, marginTop: 2 }}>{SCHEMES[scheme].label}</div>
                    </div>
                    <ProgressRing pct={prog.pct} color={color} size={52} />
                  </div>
                  <div className="progress-bar">
                    <div className="progress-fill" style={{ width: `${prog.pct}%`, background: color }} />
                  </div>
                  <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 11, color: "#555", marginTop: 6 }}>
                    {prog.done} / {prog.total} tasks complete
                  </div>
                </div>
              ))}
            </div>

            {/* Stats row */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 10, marginBottom: 20 }}>
              {[
                { label: "Total Tasks", value: alarmProg.total + cctvProg.total, color: "#fff" },
                { label: "Completed", value: alarmProg.done + cctvProg.done, color: "#22c55e" },
                { label: "Docs Uploaded", value: totalUploads, color: "#a78bfa" },
              ].map(({ label, value, color }) => (
                <div key={label} className="card" style={{ textAlign: "center", padding: "16px 10px" }}>
                  <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 28, fontWeight: 700, color }}>{value}</div>
                  <div style={{ fontSize: 11, color: "#555", marginTop: 4 }}>{label}</div>
                </div>
              ))}
            </div>

            {/* Stage guide */}
            <div className="card" style={{ marginBottom: 16 }}>
              <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 15, marginBottom: 14 }}>
                📋 Getting Started – SSAIB Roadmap
              </div>
              {[
                { step: "01", title: "Apply to SSAIB", desc: "Complete online application at ssaib.org. Pay application fee. Select Intruder Alarm and/or CCTV scheme.", done: false },
                { step: "02", title: "Build your QMS", desc: "Write your Quality Management System, procedures, and all required documentation before the audit.", done: false },
                { step: "03", title: "Vet all staff", desc: "Complete BS 7858 vetting (DBS checks, 5yr employment history) for every engineer and admin staff.", done: false },
                { step: "04", title: "Gather installation evidence", desc: "Compile at least 3 completed installation files with commissioning records for SSAIB review.", done: false },
                { step: "05", title: "Pre-assessment review", desc: "SSAIB reviews your documentation. Any gaps identified at this stage must be resolved before audit.", done: false },
                { step: "06", title: "Office & Site Audit", desc: "SSAIB assessor visits your office to review QMS, then visits a live installation site.", done: false },
                { step: "07", title: "Certificate Issued", desc: "On successful audit, SSAIB issues your certificate. You're now approved!", done: false },
              ].map(({ step, title, desc }) => (
                <div key={step} style={{ display: "flex", gap: 14, padding: "10px 0", borderBottom: "1px solid #1e1e1e" }}>
                  <div style={{
                    fontFamily: "'DM Mono', monospace", fontWeight: 700, fontSize: 13,
                    color: "#E8441A", minWidth: 28, marginTop: 1,
                  }}>{step}</div>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 3 }}>{title}</div>
                    <div style={{ fontSize: 12, color: "#666", lineHeight: 1.5 }}>{desc}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* Quick links */}
            <div className="card">
              <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 15, marginBottom: 12 }}>🔗 Useful Links</div>
              {[
                { label: "SSAIB Website", url: "https://www.ssaib.org", desc: "Apply, pay fees, download forms" },
                { label: "ICO Registration (CCTV)", url: "https://ico.org.uk/registration", desc: "Required for all CCTV companies" },
                { label: "BS 7858 Vetting Guidance", url: "https://www.bsia.co.uk", desc: "BSIA guidance on staff screening" },
              ].map(({ label, url, desc }) => (
                <div key={label} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: "1px solid #1e1e1e" }}>
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 500 }}>{label}</div>
                    <div style={{ fontSize: 11, color: "#555" }}>{desc}</div>
                  </div>
                  <a href={url} target="_blank" rel="noreferrer" style={{ fontFamily: "'DM Mono', monospace", fontSize: 11, color: "#1A7EE8", textDecoration: "none" }}>
                    Visit →
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── CHECKLIST ──────────────────────────────────────────────────── */}
        {activeTab === "checklist" && (
          <div className="fade-in">
            <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 22, marginBottom: 4 }}>Checklist</div>
            <div style={{ color: "#555", fontSize: 13, marginBottom: 16 }}>Track every requirement for accreditation</div>

            {/* Scheme selector */}
            <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
              <button className={`scheme-tab ${activeScheme === "alarm" ? "active-alarm" : ""}`} onClick={() => setActiveScheme("alarm")}>
                🔔 Intruder Alarm
              </button>
              <button className={`scheme-tab ${activeScheme === "cctv" ? "active-cctv" : ""}`} onClick={() => setActiveScheme("cctv")}>
                📷 CCTV
              </button>
            </div>

            {/* Overall scheme progress */}
            {(() => {
              const prog = schemeProgress(activeScheme);
              const color = activeScheme === "alarm" ? "#E8441A" : "#1A7EE8";
              return (
                <div className="card" style={{ marginBottom: 16, borderColor: `${color}33` }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                    <div style={{ fontWeight: 600 }}>{CHECKLIST_DATA[activeScheme].label}</div>
                    <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 13, color }}>
                      {prog.done}/{prog.total}
                    </div>
                  </div>
                  <div className="progress-bar" style={{ height: 6 }}>
                    <div className="progress-fill" style={{ width: `${prog.pct}%`, background: color }} />
                  </div>
                </div>
              );
            })()}

            {/* Sections */}
            {CHECKLIST_DATA[activeScheme].sections.map((section) => {
              const { done, total } = sectionProgress(section);
              const isOpen = expandedSections[section.id] !== false;
              const color = activeScheme === "alarm" ? "alarm-checked" : "cctv-checked";
              const accentColor = activeScheme === "alarm" ? "#E8441A" : "#1A7EE8";
              return (
                <div key={section.id} className="card" style={{ marginBottom: 10, padding: 0, overflow: "hidden" }}>
                  <div className="section-header" onClick={() => toggleSection(section.id)}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <div style={{ fontWeight: 600, fontSize: 14 }}>{section.title}</div>
                      <span className="tag" style={{ background: `${accentColor}22`, color: accentColor }}>
                        {done}/{total}
                      </span>
                    </div>
                    <div style={{ color: "#555", fontSize: 16, transition: "transform 0.2s", transform: isOpen ? "rotate(180deg)" : "none" }}>▾</div>
                  </div>
                  {isOpen && (
                    <div style={{ padding: "0 16px 12px" }}>
                      {section.items.map((item) => (
                        <div key={item.id} className="check-item" onClick={() => toggleItem(item.id)}>
                          <div className={`checkbox ${state.checked[item.id] ? color : ""}`}>
                            {state.checked[item.id] && <span style={{ color: "#fff", fontSize: 12, fontWeight: 700 }}>✓</span>}
                          </div>
                          <div style={{
                            fontSize: 13, lineHeight: 1.5, color: state.checked[item.id] ? "#555" : "#ccc",
                            textDecoration: state.checked[item.id] ? "line-through" : "none",
                            transition: "all 0.2s",
                          }}>
                            {item.text}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* ── DOCUMENTS ──────────────────────────────────────────────────── */}
        {activeTab === "documents" && (
          <div className="fade-in">
            <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 22, marginBottom: 4 }}>Document Templates</div>
            <div style={{ color: "#555", fontSize: 13, marginBottom: 16 }}>
              Ready-to-use templates — copy, fill in, save as PDF and upload as evidence
            </div>

            {/* Filters */}
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 16 }}>
              {docCategories.map(cat => (
                <button key={cat} className={`filter-btn ${docFilter === cat ? "active" : ""}`} onClick={() => setDocFilter(cat)}>
                  {cat}
                </button>
              ))}
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              {filteredDocs.map(doc => {
                const uploadCount = (state.uploads[doc.id] || []).length;
                const schemeColor = doc.scheme === "alarm" ? "#E8441A" : doc.scheme === "cctv" ? "#1A7EE8" : "#888";
                const schemeLabel = doc.scheme === "both" ? "Alarm + CCTV" : doc.scheme === "alarm" ? "Alarm" : "CCTV";
                return (
                  <div key={doc.id} className="doc-card" onClick={() => setActiveDoc(doc)}>
                    <div className="tag" style={{ background: `${schemeColor}22`, color: schemeColor, marginBottom: 8 }}>
                      {schemeLabel}
                    </div>
                    <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 4, lineHeight: 1.4 }}>{doc.title}</div>
                    <div style={{ fontSize: 11, color: "#555" }}>{doc.category}</div>
                    {uploadCount > 0 && (
                      <div style={{ marginTop: 8, fontSize: 11, color: "#22c55e" }}>
                        ✓ {uploadCount} file{uploadCount > 1 ? "s" : ""} uploaded
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── UPLOADS ──────────────────────────────────────────────────────── */}
        {activeTab === "uploads" && (
          <div className="fade-in">
            <div style={{ fontFamily: "'Syne', sans-serif", fontWeight: 700, fontSize: 22, marginBottom: 4 }}>Evidence Uploads</div>
            <div style={{ color: "#555", fontSize: 13, marginBottom: 20 }}>
              Upload your completed documents as evidence for the SSAIB audit
            </div>

            {/* Upload categories */}
            {[
              { key: "company_docs", label: "Company & Insurance Documents", desc: "Registration cert, insurance certificates, H&S policy" },
              { key: "qms_docs", label: "Quality Management System", desc: "QMS manual and all procedures" },
              { key: "staff_vetting", label: "Staff Vetting Records", desc: "BS 7858 screening, DBS checks, training certs" },
              { key: "installation_files", label: "Installation Records", desc: "Commissioning sheets, zone charts, handover docs (min 3)" },
              { key: "maintenance_agreements", label: "Maintenance Agreements", desc: "Signed customer maintenance contracts" },
              { key: "cctv_gdpr", label: "GDPR / ICO Documents", desc: "ICO certificate, privacy notices, DPIA templates" },
              { key: "engineer_certs", label: "Engineer Qualifications", desc: "BTEC, EAL, City & Guilds, manufacturer training certs" },
            ].map(({ key, label, desc }) => {
              const files = state.uploads[key] || [];
              return (
                <div key={key} className="card" style={{ marginBottom: 12 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
                    <div>
                      <div style={{ fontWeight: 600, fontSize: 14 }}>{label}</div>
                      <div style={{ fontSize: 12, color: "#555", marginTop: 2 }}>{desc}</div>
                    </div>
                    {files.length > 0 && (
                      <span className="tag" style={{ background: "#22c55e22", color: "#22c55e" }}>{files.length} file{files.length > 1 ? "s" : ""}</span>
                    )}
                  </div>

                  {/* Uploaded files */}
                  {files.length > 0 && (
                    <div style={{ marginBottom: 10 }}>
                      {files.map((file, idx) => (
                        <div key={idx} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "7px 10px", background: "#111", borderRadius: 6, marginBottom: 4 }}>
                          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                            <span style={{ fontSize: 14 }}>{file.type?.includes("pdf") ? "📄" : file.type?.includes("image") ? "🖼️" : "📎"}</span>
                            <div>
                              <div style={{ fontSize: 12, color: "#ccc" }}>{file.name}</div>
                              <div style={{ fontSize: 10, color: "#555" }}>{(file.size / 1024).toFixed(0)} KB · {new Date(file.uploadedAt).toLocaleDateString("en-GB")}</div>
                            </div>
                          </div>
                          <button onClick={() => removeUpload(key, idx)} style={{ background: "none", border: "none", color: "#555", cursor: "pointer", fontSize: 14, padding: "0 4px" }}>✕</button>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Drop zone */}
                  <label>
                    <div className="upload-zone">
                      <div style={{ fontSize: 20, marginBottom: 6 }}>⬆</div>
                      <div style={{ fontSize: 13, color: "#666" }}>Click or drag files here</div>
                      <div style={{ fontSize: 11, color: "#444", marginTop: 3 }}>PDF, Word, images accepted</div>
                    </div>
                    <input
                      type="file"
                      multiple
                      accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                      style={{ display: "none" }}
                      onChange={(e) => {
                        Array.from(e.target.files).forEach(f => handleFileUpload(key, f));
                        e.target.value = "";
                      }}
                    />
                  </label>
                </div>
              );
            })}
          </div>
        )}

      </div>

      {/* Bottom Nav */}
      <div style={{
        position: "fixed", bottom: 0, left: 0, right: 0,
        background: "#101010", borderTop: "1px solid #1e1e1e",
        display: "flex", justifyContent: "space-around", padding: "8px 0 12px",
        zIndex: 200,
      }}>
        {[
          { id: "dashboard", icon: "⬡", label: "Home" },
          { id: "checklist", icon: "◈", label: "Checklist" },
          { id: "documents", icon: "◻", label: "Templates" },
          { id: "uploads", icon: "↑", label: "Uploads" },
        ].map(({ id, icon, label }) => (
          <button key={id} className={`nav-btn ${activeTab === id ? "active" : ""}`} onClick={() => setActiveTab(id)}>
            <span style={{ fontSize: 18 }}>{icon}</span>
            {label}
            <div className="nav-dot" />
          </button>
        ))}
      </div>

      {/* Document Modal */}
      {activeDoc && (
        <div className="modal-overlay" onClick={() => setActiveDoc(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            {/* Modal header */}
            <div style={{ padding: "20px 20px 16px", borderBottom: "1px solid #222", display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
              <div>
                <div style={{ fontWeight: 700, fontSize: 16 }}>{activeDoc.title}</div>
                <div style={{ fontSize: 12, color: "#555", marginTop: 3 }}>{activeDoc.category}</div>
              </div>
              <button onClick={() => setActiveDoc(null)} style={{ background: "none", border: "none", color: "#555", cursor: "pointer", fontSize: 20, lineHeight: 1 }}>✕</button>
            </div>

            {/* Modal body */}
            <div style={{ flex: 1, overflow: "auto", padding: 20 }}>
              <pre style={{
                whiteSpace: "pre-wrap", fontFamily: "'DM Mono', monospace", fontSize: 12,
                color: "#bbb", lineHeight: 1.7, background: "#111", padding: 16,
                borderRadius: 8, border: "1px solid #222",
              }}>
                {activeDoc.content}
              </pre>

              {/* Upload for this specific doc */}
              <div style={{ marginTop: 16 }}>
                <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 8 }}>Upload completed version</div>
                {(state.uploads[activeDoc.id] || []).map((file, idx) => (
                  <div key={idx} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "7px 10px", background: "#111", borderRadius: 6, marginBottom: 4 }}>
                    <div style={{ fontSize: 12, color: "#ccc" }}>{file.name}</div>
                    <button onClick={() => removeUpload(activeDoc.id, idx)} style={{ background: "none", border: "none", color: "#555", cursor: "pointer" }}>✕</button>
                  </div>
                ))}
                <label>
                  <div className="upload-zone" style={{ padding: 14 }}>
                    <div style={{ fontSize: 12, color: "#666" }}>⬆ Upload your filled document</div>
                  </div>
                  <input type="file" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" style={{ display: "none" }}
                    onChange={(e) => { handleFileUpload(activeDoc.id, e.target.files[0]); e.target.value = ""; }} />
                </label>
              </div>
            </div>

            {/* Modal footer */}
            <div style={{ padding: "14px 20px", borderTop: "1px solid #222", display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button className="btn btn-outline" onClick={() => {
                navigator.clipboard.writeText(activeDoc.content);
                showToast("Template copied to clipboard");
              }}>Copy Template</button>
              <button className="btn btn-primary" onClick={() => setActiveDoc(null)}>Done</button>
            </div>
          </div>
        </div>
      )}

      {/* Toast */}
      {toast && <div className="toast">{toast.msg}</div>}
    </div>
  );
}
