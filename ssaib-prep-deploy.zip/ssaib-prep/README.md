# SSAIB Prep – Deployment Guide

## What's in this folder
A complete React/Vite project ready to deploy to Vercel or Netlify.

---

## Option A – Deploy to Vercel (Recommended)

1. Go to https://github.com and create a free account (if you don't have one)
2. Create a new repository called `ssaib-prep` and upload ALL these files
3. Go to https://vercel.com and sign in with your GitHub account
4. Click **"Add New Project"** → select your `ssaib-prep` repo
5. Vercel auto-detects Vite — just click **Deploy**
6. Once live, go to **Settings → Domains** and add your custom domain
7. Follow Vercel's instructions to point your domain's DNS to Vercel

Your site will be live at your domain within minutes.

---

## Option B – Deploy to Netlify

1. Go to https://netlify.com and create a free account
2. Click **"Add new site" → "Deploy manually"**
3. Run `npm install && npm run build` locally (requires Node.js installed)
4. Drag and drop the generated `dist/` folder onto Netlify
5. Go to **Site settings → Domain management** to add your custom domain

---

## Connecting your custom domain (both platforms)

You'll need to update your domain's DNS settings at your registrar
(GoDaddy, Namecheap, etc.) to point to Vercel/Netlify.

Both platforms give you exact instructions — usually:
- Add an **A record** pointing to their IP
- Add a **CNAME record** for `www`

DNS changes take up to 24 hours but usually under 1 hour.

---

## Local development (optional)

```bash
npm install
npm run dev
```
Then open http://localhost:5173
